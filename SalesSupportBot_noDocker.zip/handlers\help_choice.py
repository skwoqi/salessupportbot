from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from states import AIHelpForm
from keyboards import NAV_MENU, MAIN_MENU, ai_result_inline_kb
from services.logger import setup_logger

logger = setup_logger("AIHelp")

router = Router()


@router.message(F.text == "🤖 Помощь с выбором")
async def ai_start(message: Message, state: FSMContext):
    await state.set_state(AIHelpForm.waiting_interest)
    await message.answer("Что вас интересует?", reply_markup=NAV_MENU)


@router.message(AIHelpForm.waiting_interest)
async def ai_interest(message: Message, state: FSMContext):
    data = await state.get_data()
    data["interest"] = (message.text or "").strip()
    await state.set_data(data)

    await state.set_state(AIHelpForm.waiting_company)
    await message.answer("Опишите вашу компанию:", reply_markup=NAV_MENU)


@router.message(AIHelpForm.waiting_company)
async def ai_company(message: Message, state: FSMContext):
    data = await state.get_data()
    data["company"] = (message.text or "").strip()
    await state.set_data(data)

    await state.set_state(AIHelpForm.waiting_vision)
    await message.answer("Как вы видите идеальный результат?", reply_markup=NAV_MENU)


@router.message(AIHelpForm.waiting_vision)
async def ai_vision(message: Message, state: FSMContext, openai_service):
    data = await state.get_data()
    data["vision"] = (message.text or "").strip()
    await state.set_data(data)

    interest = data.get("interest", "")
    company = data.get("company", "")
    vision = data.get("vision", "")

    # промпт строго по схеме из ТЗ :contentReference[oaicite:2]{index=2}
    prompt = f"""
Пользователь хочет получить консультацию по выбору продукта.

Вот что его интересует: {interest}
Описание компании: {company}
Ожидаемый результат: {vision}

У нас есть следующие продукты (категория: продукт - описание):

1. Продвижение:
   - Поисковое продвижение (SEO): Выведем сайт в ТОП Яндекс и Google, поможем получать заявки из поисковых систем.
   - Продвижение в соцсетях (SMM): Стратегия присутствия бренда в соцсетях, команда специалистов.
   - Контекстная реклама (PPC): Настройка и ведение рекламных кампаний.

2. Битрикс24:
   - Базовый: Максимальная выгода от использования Битрикс24.
   - Стандартный: Быстрый запуск, эффективное использование, миграция облако->коробка.
   - Максимальный: Аудит и корректировка бизнес-процессов.

3. Веб-разработка:
   - Интернет-магазин: 1С-Битрикс, интеграции, удобная структура.
   - Корпоративный сайт: современно, адаптивно, базовая SEO.
   - Landing Page: посадочные страницы под товар/услугу.

4. Дизайн:
   - Дизайн/редизайн сайта: уникально, адаптивно, функционально.
   - Разработка логотипа: “подпись” бренда, узнаваемость.
   - Разработка фирменного стиля: полный визуальный облик бизнеса.

На основе ответов пользователя рекомендованные продукты (названия):
""".strip()

    await message.answer("Секунду… думаю 🤖")
    result = await openai_service(prompt, temperature=0.7)

    await state.clear()
    await message.answer(
        f"На основе ваших ответов, я рекомендую:\n\n{result}",
        reply_markup=ai_result_inline_kb(),
    )
    logger.info(f"AI recommendation for {message.from_user.id}")