from aiogram import Router

from .start import router as start_router
from .catalog import router as catalog_router
from .portfolio import router as portfolio_router
from .help_choice import router as help_router
from .support import router as support_router
from .admin import router as admin_router

router = Router()
router.include_router(start_router)
router.include_router(catalog_router)
router.include_router(portfolio_router)
router.include_router(help_router)
router.include_router(support_router)
router.include_router(admin_router)