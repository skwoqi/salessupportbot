import re
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from keyboards import MAIN_MENU, categories_inline_kb, products_inline_kb, NAV_MENU
from states import OrderForm
from services.logger import setup_logger

logger = setup_logger("Catalog")

router = Router()


CATALOG = {
    "promotion": [
        ("Поисковое продвижение (SEO)", "Выведем сайт в ТОП Яндекс и Google, поможем получать заявки из поисковых систем. Делаем все, что нужно: исправляем технические ошибки, делаем сайт удобнее для клиентов, наполняем полезным контентом."),
        ("Продвижение в соцсетях (SMM)", "Занимаемся разработкой и внедрением стратегии присутствия бренда в соцсетях. К этому привлекается целая команда специалистов, начиная от дизайнера и заканчивая комьюнити-менеджером."),
        ("Контекстная реклама (PPC)", "Настройка и ведение рекламных кампаний в Яндекс.Директ и Google Adwords, постоянная работа над повышением эффективности."),
    ],
    "bitrix": [
        ("Битрикс24: Базовый", "Для тех, кто хочет понять, как получить для своей компании максимальную выгоду от использования Битрикс24"),
        ("Битрикс24: Стандартный", "Быстро и правильно запустить в своей компании работу с Битрикс24. Эффективно использовать имеющийся Битрикс24. Перейти с Облачной версии на Коробочную с минимальными затратами. Интегрироваться с системами по эффективным/оптимальным сценариям."),
        ("Битрикс24: Максимальный", "Для тех, кто хочет повысить эффективность своего бизнеса за счет аудита и корректировок бизнес-процессов своей компании, используя опыт и лучшие практики в своей отрасли."),
    ],
    "web": [
        ("Интернет-магазин", "Создадим легкий в управлении интернет-магазин на платформе 1С-Битрикс. Продумаем функционал: сортировку и фильтрацию товаров, добавление новых товаров и т.д. Интегрируем с вашей CRM и платежными системами. Позаботимся о понятной структуре, удобстве пользования и привлекательном дизайне."),
        ("Корпоративный сайт", "Разработаем современный корпоративный сайт на 1С-Битрикс с мобильной версией и базовой SEO-оптимизацией. Позаботимся о том, чтобы сайт максимально соответствовал задачам вашего бизнеса и ожиданиям целевой аудитории."),
        ("Landing Page", "Разрабатываем посадочные страницы для конкретного товара или услуги. Вы получите готовый инструмент для привлечения клиентов. Лендинг будет отвечать вашим бизнес-задачам, соответствовать пользовательским предпочтениям и точно подведет посетителей к совершению целевого действия."),
    ],
    "design": [
        ("Дизайн/редизайн сайта", "Независимо от того для какого сайта разрабатывается дизайн: лендинга, интернет-магазина или корпоративного сайта, он будет уникальным и адаптивным. Целая команда специалистов работает над тем, чтобы все элементы, баннеры и кнопки были максимально функциональны."),
        ("Разработка логотипа", "Логотип — визитная карточка вашей компании, своего рода «подпись» бренда. Это то, что размещается на всей продукции и способствует продвижению компании. Вы сможете выделиться среди конкурентов и стать узнаваемым и сильным брендом."),
        ("Разработка фирменного стиля", "Фирменный стиль — визуальный облик вашего бизнеса, создающий индивидуальность и подчеркивающий позиционирование компании на рынке. Раскроем суть вашей компании и упакуем это в стиль."),
    ],
}

CAT_TITLES = {
    "promotion": "Продвижение",
    "bitrix": "Битрикс24 (можно выбрать только 1)",
    "web": "Веб-разработка",
    "design": "Дизайн",
}


def _phone_ok(s: str) -> bool:
    # супер лайтовая проверка: цифры, +, пробелы, дефисы
    s = s.strip()
    return bool(re.fullmatch(r"[+0-9()\-\s]{7,20}", s))


async def show_categories(target, state: FSMContext):
    await state.set_state(OrderForm.choosing_products)
    data = await state.get_data()
    data.setdefault("selected_products", [])
    data.setdefault("bitrix_selected", None)
    await state.set_data(data)

    await target.answer("Выбери категорию 👇", reply_markup=categories_inline_kb())


async def show_products(cb: CallbackQuery, state: FSMContext, cat_key: str):
    data = await state.get_data()
    selected = set(data.get("selected_products", []))
    bitrix_selected = data.get("bitrix_selected")

    products = CATALOG[cat_key]
    lines = [f"*{CAT_TITLES[cat_key]}*\n"]
    for name, desc in products:
        lines.append(f"• *{name}*\n_{desc}_\n")

    show_done = cat_key != "bitrix"
    kb = products_inline_kb(
        category_key=cat_key,
        products=products,
        selected=selected,
        bitrix_selected=bitrix_selected,
        show_done=show_done,
    )
    await cb.message.edit_text("\n".join(lines), reply_markup=kb, parse_mode="Markdown")


@router.message(F.text == "📋 Каталог")
async def menu_catalog(message: Message, state: FSMContext):
    await show_categories(message, state)
    logger.info(f"open catalog by {message.from_user.id}")


@router.callback_query(F.data.startswith("cat:"))
async def cat_pick(cb: CallbackQuery, state: FSMContext):
    cat_key = cb.data.split(":", 1)[1]
    if cat_key not in CATALOG:
        await cb.answer("Не понял категорию 🙃")
        return
    await show_products(cb, state, cat_key)
    await cb.answer()


@router.callback_query(F.data == "back:cats")
async def back_to_categories(cb: CallbackQuery, state: FSMContext):
    await cb.message.edit_text("Выбери категорию 👇", reply_markup=categories_inline_kb())
    await cb.answer()


@router.callback_query(F.data.startswith("prod:"))
async def product_toggle(cb: CallbackQuery, state: FSMContext):
    _, cat_key, idx_s = cb.data.split(":")
    idx = int(idx_s)

    if cat_key not in CATALOG or idx < 0 or idx >= len(CATALOG[cat_key]):
        await cb.answer("Что-то пошло не так")
        return

    data = await state.get_data()
    selected = set(data.get("selected_products", []))
    bitrix_selected = data.get("bitrix_selected")

    name, _desc = CATALOG[cat_key][idx]

    if cat_key == "bitrix":
        # можно выбрать только один: если выбирают новый — заменяем
        bitrix_selected = name
        # убираем любые другие bitrix из selected
        for n, _ in CATALOG["bitrix"]:
            selected.discard(n)
        selected.add(name)

        data["bitrix_selected"] = bitrix_selected
        data["selected_products"] = list(selected)
        await state.set_data(data)

        # авто-переход к заявке по ТЗ
        await state.set_state(OrderForm.waiting_name)
        await cb.message.answer(
            f"Ок, выбрано: *{name}*\n\nНапишите ваше имя:",
            parse_mode="Markdown",
            reply_markup=NAV_MENU,
        )
        await cb.answer("Принято ✅")
        return

    # обычная категория: toggle
    if name in selected:
        selected.remove(name)
    else:
        selected.add(name)

    data["selected_products"] = list(selected)
    await state.set_data(data)

    await show_products(cb, state, cat_key)
    await cb.answer("Готово")


@router.callback_query(F.data == "done")
async def done_products(cb: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    selected = data.get("selected_products", [])
    if not selected:
        await cb.answer("Сначала выбери хотя бы 1 продукт 🙂", show_alert=True)
        return

    await state.set_state(OrderForm.waiting_name)
    await cb.message.answer("Супер. Напишите ваше имя:", reply_markup=NAV_MENU)
    await cb.answer()


@router.message(OrderForm.waiting_name)
async def order_name(message: Message, state: FSMContext):
    txt = (message.text or "").strip()
    if txt in ("🏠 Главное меню", "🔙 Назад"):
        # обработается в глобальных хендлерах (ниже), но пусть тут будет safe
        return

    data = await state.get_data()
    data["name"] = txt
    await state.set_data(data)
    await state.set_state(OrderForm.waiting_phone)
    await message.answer("Теперь телефон (можно с +):", reply_markup=NAV_MENU)


@router.message(OrderForm.waiting_phone)
async def order_phone(message: Message, state: FSMContext):
    txt = (message.text or "").strip()
    if not _phone_ok(txt):
        await message.answer("Телефон выглядит странно 😅 Введите ещё раз (цифры/+/-/пробелы):")
        return

    data = await state.get_data()
    data["phone"] = txt
    await state.set_data(data)
    await state.set_state(OrderForm.waiting_email)
    await message.answer("И email:", reply_markup=NAV_MENU)


@router.message(OrderForm.waiting_email)
async def order_email(message: Message, state: FSMContext, db, bitrix_service):
    email = (message.text or "").strip()
    if "@" not in email or "." not in email:
        await message.answer("Email как будто мимо. Введите нормальный 🙂")
        return

    data = await state.get_data()
    data["email"] = email
    selected = data.get("selected_products", [])
    name = data.get("name")
    phone = data.get("phone")

    # сохраняем в users
    u = message.from_user
    await db.upsert_user(
        UserRow(
            telegram_id=u.id,
            username=u.username,
            first_name=u.first_name,
            last_name=u.last_name,
            phone=phone,
            email=email,
        )
    )

    payload = {
        "type": "order",
        "user": {
            "telegram_id": u.id,
            "username": f"@{u.username}" if u.username else None,
            "name": name,
            "phone": phone,
            "email": email,
        },
        "products": selected,
    }

    await bitrix_service(payload)
    await db.create_application(
        telegram_id=u.id,
        app_type="order",
        products=selected,
        name=name,
        phone=phone,
        email=email,
    )

    await state.clear()
    await message.answer(
        "Заявка принята ✅\nМы свяжемся с вами в ближайшее время.",
        reply_markup=MAIN_MENU,
    )
    logger.info(f"order saved from {u.id} products={selected}")


# ---- навигация кнопками ----

@router.message(F.text == "🏠 Главное меню")
async def go_menu(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("Ок, вернул в меню 👇", reply_markup=MAIN_MENU)


@router.message(F.text == "🔙 Назад")
async def go_back(message: Message, state: FSMContext):
    st = await state.get_state()
    if st == OrderForm.waiting_phone.state:
        await state.set_state(OrderForm.waiting_name)
        await message.answer("Назад. Напишите имя:", reply_markup=NAV_MENU)
    elif st == OrderForm.waiting_email.state:
        await state.set_state(OrderForm.waiting_phone)
        await message.answer("Назад. Напишите телефон:", reply_markup=NAV_MENU)
    else:
        # если некуда откатываться — просто каталог/меню
        await message.answer("Назад — это куда? 😄 Держи меню.", reply_markup=MAIN_MENU)


@router.callback_query(F.data == "nav:menu")
async def nav_menu(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await cb.message.answer("Меню 👇", reply_markup=MAIN_MENU)
    await cb.answer()