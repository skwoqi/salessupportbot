import asyncio
from aiohttp import web

from aiohttp import ClientTimeout
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application

from config import settings
from database import Database, SQLiteStorage
from handlers import router as main_router
from services.logger import setup_logger
from services.bitrix24 import send_to_bitrix24
from services.openai_service import OpenAIService

logger = setup_logger("Main")


async def main():
    db = Database()
    await db.init()

    storage = SQLiteStorage()  # FSM persistence в SQLite (таблица conversations) :contentReference[oaicite:3]{index=3}

    timeout = ClientTimeout(total=60)  # 60 секунд вместо дефолта
    bot = Bot(
    token=settings.bot_token,
    default=DefaultBotProperties(parse_mode="HTML"),
)

    dp = Dispatcher(storage=storage)
    dp.include_router(main_router)

    openai = OpenAIService(settings.openai_api_key, settings.openai_model)

    async def bitrix_wrapper(payload: dict) -> bool:
        return await send_to_bitrix24(settings.bitrix24_webhook_url, payload)

    # зависимости в хендлеры через workflow data
    dp["db"] = db
    dp["bitrix_service"] = bitrix_wrapper
    dp["openai_service"] = openai.recommend

    if not settings.use_webhook:
        logger.info("Starting in polling mode")
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot)
        return

    # Webhook mode
    if not settings.base_url:
        raise RuntimeError("USE_WEBHOOK=1, but BASE_URL is empty")

    webhook_url = f"{settings.base_url}{settings.webhook_path}"
    logger.info(f"Starting in webhook mode: {webhook_url}")

    await bot.set_webhook(webhook_url)

    app = web.Application()
    SimpleRequestHandler(dispatcher=dp, bot=bot).register(app, path=settings.webhook_path)
    setup_application(app, dp, bot=bot)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host=settings.web_server_host, port=settings.web_server_port)
    await site.start()

    logger.info(f"Webhook server started on {settings.web_server_host}:{settings.web_server_port}")
    # держим процесс живым
    while True:
        await asyncio.sleep(3600)


if __name__ == "__main__":
    asyncio.run(main())