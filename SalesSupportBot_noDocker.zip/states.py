from aiogram.fsm.state import State, StatesGroup


class OrderForm(StatesGroup):
    choosing_products = State()
    waiting_name = State()
    waiting_phone = State()
    waiting_email = State()


class SupportForm(StatesGroup):
    waiting_name = State()
    waiting_phone = State()
    waiting_email = State()
    waiting_problem = State()


class AIHelpForm(StatesGroup):
    waiting_interest = State()
    waiting_company = State()
    waiting_vision = State()