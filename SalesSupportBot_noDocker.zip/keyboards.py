from aiogram.types import (
    ReplyKeyboardMarkup,
    KeyboardButton,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder


MAIN_MENU = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="📋 Каталог"), KeyboardButton(text="🖼️ Портфолио")],
        [KeyboardButton(text="🤖 Помощь с выбором"), KeyboardButton(text="📞 Консультация")],
    ],
    resize_keyboard=True,
)

NAV_MENU = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🔙 Назад"), KeyboardButton(text="🏠 Главное меню")],
    ],
    resize_keyboard=True,
)

def portfolio_inline_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="📋 Перейти в каталог", callback_data="nav:catalog")
    b.button(text="🏠 Главное меню", callback_data="nav:menu")
    b.adjust(1)
    return b.as_markup()

def ai_result_inline_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="📋 Перейти в каталог", callback_data="nav:catalog")
    b.button(text="🏠 Главное меню", callback_data="nav:menu")
    b.adjust(1)
    return b.as_markup()

def categories_inline_kb() -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="1) Продвижение", callback_data="cat:promotion")
    b.button(text="2) Битрикс24", callback_data="cat:bitrix")
    b.button(text="3) Веб-разработка", callback_data="cat:web")
    b.button(text="4) Дизайн", callback_data="cat:design")
    b.adjust(1)
    b.row(InlineKeyboardButton(text="🏠 Главное меню", callback_data="nav:menu"))
    return b.as_markup()

def products_inline_kb(
    category_key: str,
    products: list[tuple[str, str]],
    selected: set[str],
    bitrix_selected: str | None,
    show_done: bool,
) -> InlineKeyboardMarkup:
    """
    products: [(name, description), ...]
    selected: set of product names selected (across all categories)
    bitrix_selected: selected product name in bitrix category (only one allowed)
    """
    b = InlineKeyboardBuilder()

    for idx, (name, _desc) in enumerate(products):
        is_selected = name in selected
        label = f"{'✅ ' if is_selected else ''}{name}"

        if category_key == "bitrix":
            # блокируем остальные, если один уже выбран
            if bitrix_selected and name != bitrix_selected:
                label = f"🚫 {name}"
                cb = "noop"
            else:
                cb = f"prod:{category_key}:{idx}"
        else:
            cb = f"prod:{category_key}:{idx}"

        b.button(text=label, callback_data=cb)

    b.adjust(1)

    if show_done:
        b.row(InlineKeyboardButton(text="✅ Готово", callback_data="done"))
    b.row(InlineKeyboardButton(text="🔙 Назад", callback_data="back:cats"))
    b.row(InlineKeyboardButton(text="🏠 Главное меню", callback_data="nav:menu"))
    return b.as_markup()