import aiohttp
from services.logger import setup_logger

logger = setup_logger("Bitrix24")


async def send_to_bitrix24(webhook_url: str, application_data: dict) -> bool:
    """
    Заглушка по ТЗ:
    - если webhook_url пустой -> пишем в лог и считаем "успех"
    - если webhook_url задан -> пробуем POST (но всё равно логируем)
    """
    logger.info(f"[Bitrix24] application payload: {application_data}")

    if not webhook_url:
        logger.info("[Bitrix24] webhook_url not set -> logged only (stub mode)")
        return True

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(webhook_url, json=application_data, timeout=10) as resp:
                ok = 200 <= resp.status < 300
                logger.info(f"[Bitrix24] POST status={resp.status} ok={ok}")
                return ok
    except Exception as e:
        logger.exception(f"[Bitrix24] POST failed: {e}")
        # чтобы не рушить продажи, считаем как "приняли" (как заглушка)
        return True