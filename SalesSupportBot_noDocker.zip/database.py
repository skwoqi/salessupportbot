import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import aiosqlite
from aiogram.fsm.storage.base import BaseStorage, StorageKey


DB_PATH = Path(__file__).resolve().parent / "bot.db"


CREATE_USERS = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER UNIQUE NOT NULL,
    username TEXT,
    first_name TEXT,
    last_name TEXT,
    phone TEXT,
    email TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

CREATE_APPLICATIONS = """
CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER NOT NULL,
    type TEXT CHECK(type IN ('order', 'support')),
    products TEXT,
    name TEXT,
    phone TEXT,
    email TEXT,
    problem_description TEXT,
    status TEXT DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (telegram_id) REFERENCES users(telegram_id)
);
"""

CREATE_CONVERSATIONS = """
CREATE TABLE IF NOT EXISTS conversations (
    telegram_id INTEGER PRIMARY KEY,
    state TEXT,
    data TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""


@dataclass
class UserRow:
    telegram_id: int
    username: str | None
    first_name: str | None
    last_name: str | None
    phone: str | None
    email: str | None


class Database:
    def __init__(self, path: Path = DB_PATH):
        self.path = path

    async def init(self) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(CREATE_USERS)
            await db.execute(CREATE_APPLICATIONS)
            await db.execute(CREATE_CONVERSATIONS)
            await db.commit()

    async def upsert_user(self, user: UserRow) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                """
                INSERT INTO users (telegram_id, username, first_name, last_name, phone, email)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(telegram_id) DO UPDATE SET
                    username=excluded.username,
                    first_name=excluded.first_name,
                    last_name=excluded.last_name,
                    phone=COALESCE(excluded.phone, users.phone),
                    email=COALESCE(excluded.email, users.email)
                """,
                (user.telegram_id, user.username, user.first_name, user.last_name, user.phone, user.email),
            )
            await db.commit()

    async def create_application(
        self,
        telegram_id: int,
        app_type: str,
        products: list[str] | None,
        name: str | None,
        phone: str | None,
        email: str | None,
        problem_description: str | None = None,
    ) -> int:
        async with aiosqlite.connect(self.path) as db:
            cur = await db.execute(
                """
                INSERT INTO applications (telegram_id, type, products, name, phone, email, problem_description)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    telegram_id,
                    app_type,
                    json.dumps(products or [], ensure_ascii=False),
                    name,
                    phone,
                    email,
                    problem_description,
                ),
            )
            await db.commit()
            return int(cur.lastrowid)

    async def list_users(self, limit: int = 500) -> list[dict[str, Any]]:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute(
                "SELECT telegram_id, username, first_name, last_name, phone, email, created_at FROM users ORDER BY created_at DESC LIMIT ?",
                (limit,),
            )
            rows = await cur.fetchall()
            return [dict(r) for r in rows]

    async def list_applications(self, limit: int = 500) -> list[dict[str, Any]]:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute(
                """
                SELECT id, telegram_id, type, products, name, phone, email, problem_description, status, created_at
                FROM applications
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (limit,),
            )
            rows = await cur.fetchall()
            out = []
            for r in rows:
                d = dict(r)
                try:
                    d["products"] = json.loads(d["products"] or "[]")
                except Exception:
                    d["products"] = []
                out.append(d)
            return out

    async def close_application(self, app_id: int) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute("UPDATE applications SET status='closed' WHERE id=?", (app_id,))
            await db.commit()

    async def stats(self) -> dict[str, Any]:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row

            async def one(sql: str) -> int:
                cur = await db.execute(sql)
                row = await cur.fetchone()
                return int(row[0]) if row else 0

            total_users = await one("SELECT COUNT(*) FROM users")
            total_apps = await one("SELECT COUNT(*) FROM applications")
            open_apps = await one("SELECT COUNT(*) FROM applications WHERE status='new'")
            closed_apps = await one("SELECT COUNT(*) FROM applications WHERE status='closed'")

            today = await one("SELECT COUNT(*) FROM applications WHERE date(created_at)=date('now')")
            week = await one("SELECT COUNT(*) FROM applications WHERE datetime(created_at) >= datetime('now','-7 days')")
            month = await one("SELECT COUNT(*) FROM applications WHERE datetime(created_at) >= datetime('now','-30 days')")

            return {
                "total_users": total_users,
                "total_applications": total_apps,
                "open_applications": open_apps,
                "closed_applications": closed_apps,
                "applications_today": today,
                "applications_week": week,
                "applications_month": month,
            }


# ---- FSM Storage in SQLite (table conversations) ----

class SQLiteStorage(BaseStorage):
    """
    Хранит aiogram FSM state+data в таблице conversations.
    Ключ: telegram_id
    """

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path

    async def close(self) -> None:
        return

    async def wait_closed(self) -> None:
        return

    async def _get_row(self, telegram_id: int) -> tuple[str | None, dict[str, Any]]:
        async with aiosqlite.connect(self.db_path) as db:
            cur = await db.execute(
                "SELECT state, data FROM conversations WHERE telegram_id=?",
                (telegram_id,),
            )
            row = await cur.fetchone()
            if not row:
                return None, {}
            state, data = row
            try:
                parsed = json.loads(data) if data else {}
            except Exception:
                parsed = {}
            return state, parsed

    async def _upsert(self, telegram_id: int, state: str | None, data: dict[str, Any]) -> None:
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                INSERT INTO conversations (telegram_id, state, data)
                VALUES (?, ?, ?)
                ON CONFLICT(telegram_id) DO UPDATE SET
                    state=excluded.state,
                    data=excluded.data,
                    updated_at=CURRENT_TIMESTAMP
                """,
                (telegram_id, state, json.dumps(data, ensure_ascii=False)),
            )
            await db.commit()

    def _tid(self, key: StorageKey) -> int:
        # aiogram storage key содержит user_id
        return int(key.user_id)

    async def set_state(self, key: StorageKey, state: str | None = None) -> None:
        telegram_id = self._tid(key)
        _, data = await self._get_row(telegram_id)
        await self._upsert(telegram_id, state, data)

    async def get_state(self, key: StorageKey) -> str | None:
        telegram_id = self._tid(key)
        state, _ = await self._get_row(telegram_id)
        return state

    async def set_data(self, key: StorageKey, data: dict[str, Any]) -> None:
        telegram_id = self._tid(key)
        state, _ = await self._get_row(telegram_id)
        await self._upsert(telegram_id, state, data)

    async def get_data(self, key: StorageKey) -> dict[str, Any]:
        telegram_id = self._tid(key)
        _, data = await self._get_row(telegram_id)
        return data

    async def update_data(self, key: StorageKey, data: dict[str, Any]) -> dict[str, Any]:
        telegram_id = self._tid(key)
        state, old = await self._get_row(telegram_id)
        old.update(data)
        await self._upsert(telegram_id, state, old)
        return old