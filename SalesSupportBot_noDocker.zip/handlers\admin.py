from aiogram import Router
from aiogram.types import Message
from aiogram.filters import Command

from config import settings
from keyboards import MAIN_MENU
from services.logger import setup_logger

logger = setup_logger("Admin")

router = Router()


def _is_admin(user_id: int) -> bool:
    return settings.admin_telegram_id and user_id == settings.admin_telegram_id


@router.message(Command("admin"))
async def admin_cmd(message: Message, db):
    uid = message.from_user.id
    if not _is_admin(uid):
        return

    s = await db.stats()

    admin_url = f"http://localhost:{settings.admin_port}/admin/dashboard?token={settings.admin_secret_token}"
    # если у тебя админка не локальная — просто поменяешь url на домен в сообщении
    text = (
        "🛡️ Админ режим\n\n"
        f"Пользователей: {s['total_users']}\n"
        f"Заявок всего: {s['total_applications']}\n"
        f"Открытых: {s['open_applications']} | Закрытых: {s['closed_applications']}\n"
        f"Сегодня: {s['applications_today']} | Неделя: {s['applications_week']} | Месяц: {s['applications_month']}\n\n"
        f"Админка (c токеном):\n{admin_url}\n\n"
        "Если у тебя прод-домен, просто замени localhost на него."
    )
    await message.answer(text, reply_markup=MAIN_MENU)
    logger.info(f"admin opened by {uid}")