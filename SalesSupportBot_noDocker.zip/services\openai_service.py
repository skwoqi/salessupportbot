from openai import AsyncOpenAI
from services.logger import setup_logger

logger = setup_logger("OpenAI")


class OpenAIService:
    def __init__(self, api_key: str, model: str):
        self.model = model
        self.enabled = bool(api_key)
        self.client = AsyncOpenAI(api_key=api_key) if api_key else None

    async def recommend(self, prompt: str, temperature: float = 0.7) -> str:
        if not self.enabled or not self.client:
            return "AI сейчас выключен (нет OPENAI_API_KEY)."

        try:
            # По SDK: chat.completions.create (OpenAI python 1.x). :contentReference[oaicite:1]{index=1}
            resp = await self.client.chat.completions.create(
                model=self.model,
                temperature=temperature,
                messages=[
                    {"role": "system", "content": "Ты консультант IT-агентства. Отвечай кратко и по делу. Верни список названий продуктов и 1-2 причины."},
                    {"role": "user", "content": prompt},
                ],
            )
            text = (resp.choices[0].message.content or "").strip()
            return text if text else "Не получилось сформировать рекомендацию. Попробуйте ещё раз."
        except Exception as e:
            logger.exception(f"OpenAI error: {e}")
            return "AI временно буксует 😵‍💫 Попробуйте позже."