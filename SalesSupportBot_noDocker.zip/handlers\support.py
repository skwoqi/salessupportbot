import re
from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext

from states import SupportForm
from keyboards import NAV_MENU, MAIN_MENU
from database import UserRow
from services.logger import setup_logger

logger = setup_logger("Support")

router = Router()


def _phone_ok(s: str) -> bool:
    s = s.strip()
    return bool(re.fullmatch(r"[+0-9()\-\s]{7,20}", s))


@router.message(F.text == "📞 Консультация")
async def support_start(message: Message, state: FSMContext):
    await state.set_state(SupportForm.waiting_name)
    await message.answer("Как к вам обращаться? (имя)", reply_markup=NAV_MENU)


@router.message(SupportForm.waiting_name)
async def support_name(message: Message, state: FSMContext):
    data = await state.get_data()
    data["name"] = (message.text or "").strip()
    await state.set_data(data)

    await state.set_state(SupportForm.waiting_phone)
    await message.answer("Телефон:", reply_markup=NAV_MENU)


@router.message(SupportForm.waiting_phone)
async def support_phone(message: Message, state: FSMContext):
    phone = (message.text or "").strip()
    if not _phone_ok(phone):
        await message.answer("Телефон странный 😅 Введите ещё раз (цифры/+/-/пробелы):")
        return

    data = await state.get_data()
    data["phone"] = phone
    await state.set_data(data)

    await state.set_state(SupportForm.waiting_email)
    await message.answer("Email:", reply_markup=NAV_MENU)


@router.message(SupportForm.waiting_email)
async def support_email(message: Message, state: FSMContext):
    email = (message.text or "").strip()
    if "@" not in email or "." not in email:
        await message.answer("Email как будто не email 🙂 Введите ещё раз:")
        return

    data = await state.get_data()
    data["email"] = email
    await state.set_data(data)

    await state.set_state(SupportForm.waiting_problem)
    await message.answer("Опишите проблему / запрос:", reply_markup=NAV_MENU)


@router.message(SupportForm.waiting_problem)
async def support_problem(message: Message, state: FSMContext, db, bitrix_service):
    data = await state.get_data()
    problem = (message.text or "").strip()

    name = data.get("name")
    phone = data.get("phone")
    email = data.get("email")

    u = message.from_user
    await db.upsert_user(
        UserRow(
            telegram_id=u.id,
            username=u.username,
            first_name=u.first_name,
            last_name=u.last_name,
            phone=phone,
            email=email,
        )
    )

    payload = {
        "type": "support",
        "user": {
            "telegram_id": u.id,
            "username": f"@{u.username}" if u.username else None,
            "name": name,
            "phone": phone,
            "email": email,
        },
        "problem_description": problem,
    }

    await bitrix_service(payload)
    await db.create_application(
        telegram_id=u.id,
        app_type="support",
        products=None,
        name=name,
        phone=phone,
        email=email,
        problem_description=problem,
    )

    await state.clear()
    await message.answer("Принято ✅ Мы скоро ответим.", reply_markup=MAIN_MENU)
    logger.info(f"support saved from {u.id}")