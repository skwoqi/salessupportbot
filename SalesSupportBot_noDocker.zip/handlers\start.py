from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import CommandStart

from config import settings
from keyboards import MAIN_MENU
from database import Database, UserRow
from services.logger import setup_logger

logger = setup_logger("Start")

router = Router()


@router.message(CommandStart())
async def cmd_start(message: Message, db: Database):
    u = message.from_user
    await db.upsert_user(
        UserRow(
            telegram_id=u.id,
            username=u.username,
            first_name=u.first_name,
            last_name=u.last_name,
            phone=None,
            email=None,
        )
    )

    text = (
        f"Привет! Я бот {settings.company_name}.\n\n"
        "Могу:\n"
        "• показать каталог услуг\n"
        "• помочь выбрать через AI\n"
        "• собрать заявку / консультацию\n\n"
        "Жми кнопку ниже 👇"
    )
    await message.answer(text, reply_markup=MAIN_MENU)
    logger.info(f"/start from {u.id}")