from aiogram import Router, F
from aiogram.types import Message, CallbackQuery

from config import settings
from keyboards import portfolio_inline_kb, MAIN_MENU
from services.logger import setup_logger

logger = setup_logger("Portfolio")

router = Router()


@router.message(F.text == "🖼️ Портфолио")
async def portfolio(message: Message):
    await message.answer(
        f"Портфолио: {settings.portfolio_url}",
        reply_markup=portfolio_inline_kb(),
    )
    logger.info(f"portfolio opened by {message.from_user.id}")


@router.callback_query(F.data == "nav:catalog")
async def goto_catalog(cb: CallbackQuery, state):
    # триггерим каталог через сообщение (чтоб не дублировать логику)
    await cb.message.answer("Открываю каталог 👇", reply_markup=MAIN_MENU)
    await cb.answer()