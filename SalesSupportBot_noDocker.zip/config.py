import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


def _get_env(name: str, default: str | None = None) -> str:
    val = os.getenv(name, default)
    if val is None:
        raise RuntimeError(f"Missing env var: {name}")
    return val


@dataclass(frozen=True)
class Settings:
    # Telegram
    bot_token: str = _get_env("BOT_TOKEN")

    # OpenAI
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo")

    # Bitrix24
    bitrix24_webhook_url: str = os.getenv("BITRIX24_WEBHOOK_URL", "").strip()

    # Admin
    admin_secret_token: str = _get_env("ADMIN_SECRET_TOKEN", "change_me")
    admin_username: str = _get_env("ADMIN_USERNAME", "admin")
    admin_password: str = _get_env("ADMIN_PASSWORD", "strong_password")
    admin_telegram_id: int = int(_get_env("ADMIN_TELEGRAM_ID", "0"))

    # Branding / links
    company_name: str = os.getenv("COMPANY_NAME", "IT-агентство")
    portfolio_url: str = os.getenv("PORTFOLIO_URL", "https://ваш-сайт.ру/portfolio")

    # Webhook (optional)
    use_webhook: bool = os.getenv("USE_WEBHOOK", "0") == "1"
    base_url: str = os.getenv("BASE_URL", "").rstrip("/")
    webhook_path: str = os.getenv("WEBHOOK_PATH", "/webhook")
    web_server_host: str = os.getenv("WEB_SERVER_HOST", "0.0.0.0")
    web_server_port: int = int(os.getenv("WEB_SERVER_PORT", "8080"))

    # FastAPI
    admin_host: str = os.getenv("ADMIN_HOST", "0.0.0.0")
    admin_port: int = int(os.getenv("ADMIN_PORT", "8000"))


settings = Settings()