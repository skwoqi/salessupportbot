import hmac
import hashlib
import time
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates

from config import settings
from database import Database

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

app = FastAPI()
db = Database()


def _sign(value: str) -> str:
    return hmac.new(
        settings.admin_secret_token.encode("utf-8"),
        value.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def _make_cookie(username: str) -> str:
    ts = str(int(time.time()))
    raw = f"{username}|{ts}"
    sig = _sign(raw)
    return f"{raw}|{sig}"


def _check_cookie(cookie: str | None, ttl_sec: int = 60 * 60 * 24 * 7) -> bool:
    if not cookie:
        return False
    parts = cookie.split("|")
    if len(parts) != 3:
        return False
    username, ts_s, sig = parts
    raw = f"{username}|{ts_s}"
    if not hmac.compare_digest(_sign(raw), sig):
        return False
    try:
        ts = int(ts_s)
    except ValueError:
        return False
    return (time.time() - ts) <= ttl_sec


def _is_authed(request: Request) -> bool:
    # 1) token в query или header
    token = request.query_params.get("token") or request.headers.get("X-Admin-Token")
    if token and token == settings.admin_secret_token:
        return True

    # 2) "доступ по Telegram ID" (как в ТЗ): если tg_id совпадает с ADMIN_TELEGRAM_ID
    tg_id = request.query_params.get("tg_id")
    if tg_id and settings.admin_telegram_id and tg_id.isdigit() and int(tg_id) == settings.admin_telegram_id:
        return True

    # 3) cookie-сессия
    return _check_cookie(request.cookies.get("admin_session"))


def _require_auth(request: Request) -> None:
    if not _is_authed(request):
        raise HTTPException(status_code=401, detail="Not authorized")


@app.on_event("startup")
async def on_startup():
    await db.init()


@app.get("/admin/login", response_class=HTMLResponse)
async def login_form(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.post("/admin/login")
async def login(request: Request, username: str = Form(...), password: str = Form(...)):
    if username != settings.admin_username or password != settings.admin_password:
        return templates.TemplateResponse(
            "login.html",
            {"request": request, "error": "Неверный логин или пароль"},
            status_code=400,
        )

    resp = RedirectResponse(url="/admin/dashboard", status_code=303)
    resp.set_cookie("admin_session", _make_cookie(username), httponly=True, samesite="lax")
    return resp


@app.get("/admin/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    _require_auth(request)
    s = await db.stats()
    return templates.TemplateResponse("dashboard.html", {"request": request, "stats": s})


@app.get("/admin/users", response_class=HTMLResponse)
async def users(request: Request):
    _require_auth(request)
    rows = await db.list_users()
    return templates.TemplateResponse("users.html", {"request": request, "users": rows})


@app.get("/admin/applications", response_class=HTMLResponse)
async def applications(request: Request):
    _require_auth(request)
    rows = await db.list_applications()
    return templates.TemplateResponse("applications.html", {"request": request, "apps": rows})


@app.post("/admin/applications/{app_id}/close")
async def close_application(request: Request, app_id: int):
    _require_auth(request)
    await db.close_application(app_id)
    return RedirectResponse(url="/admin/applications", status_code=303)


@app.get("/admin/stats")
async def stats(request: Request):
    _require_auth(request)
    s = await db.stats()
    return JSONResponse(s)